-- Create the database if it doesn't exist
CREATE DATABASE IF NOT EXISTS form_db;

-- Use the created database
USE form_db;

-- Create the 'kontak' table if it doesn't exist, including the 'umur' column
CREATE TABLE IF NOT EXISTS kontak (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nama VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL,
    umur INT, -- Added 'umur' column
    pesan TEXT NOT NULL,
    waktu TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Example INSERT statement with the new 'umur' column
-- This example assumes 'umur' is 30 for Andi.
INSERT INTO kontak (nama, email, umur, pesan) VALUES
('Andi', 'andi@example.com', 30, 'Halo, ini pesan pertama.');
